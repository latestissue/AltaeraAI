# This is a default distribution plug-in.
# Do not modify this file as your changes will be overwritten on next update.
# If you want customize installation, please make a copy.
DISTRO_NAME="Manjaro AArch64"
DISTRO_COMMENT="Currently available only for AArch64."

TARBALL_URL['aarch64']="https://github.com/termux/proot-distro/releases/download/v3.10.0/manjaro-aarch64-pd-v3.10.0.tar.xz"
TARBALL_SHA256['aarch64']="a56ee2ce0b56bf522325f82de20529862bb46540dfdb0febc151abf9e932a3f8"
